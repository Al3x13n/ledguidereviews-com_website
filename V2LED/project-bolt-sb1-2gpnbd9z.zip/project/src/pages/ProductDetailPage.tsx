import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Star, ArrowLeft, ExternalLink, Shield, Zap, Award, CheckCircle, XCircle } from 'lucide-react';
import AdPlacement from '../components/AdPlacement';

// Product database - in a real app, this would come from an API or database
const productDatabase = {
  'vava-baby-night-light-va-cl006': {
    title: 'VAVA Baby Night Light VA-CL006',
    description: 'Soft silicone night light with touch control and timer function',
    rating: 4.6,
    price: '$19.99',
    originalPrice: '$24.99',
    image: 'https://images.pexels.com/photos/1329297/pexels-photo-1329297.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'LED Night Lights',
    categoryPath: '/led-night-lights',
    features: [
      'Soft silicone design safe for children',
      'Touch control with easy operation',
      '1-hour auto timer function',
      'USB rechargeable battery',
      'Warm white LED light',
      'Portable and lightweight design',
      'BPA-free materials',
      'Multiple brightness levels'
    ],
    specifications: {
      'Dimensions': '4.3 x 4.3 x 4.7 inches',
      'Weight': '8.8 ounces',
      'Battery Life': 'Up to 200 hours (lowest setting)',
      'Charging Time': '2.5 hours',
      'Light Color': 'Warm White (3000K)',
      'Material': 'Food-grade silicone',
      'Warranty': '18 months',
      'Certifications': 'FCC, CE, RoHS'
    },
    pros: [
      'Completely safe for children with soft silicone construction',
      'Excellent battery life lasting up to 200 hours',
      'Cute and appealing design that kids love',
      'Easy touch controls that children can operate',
      'Portable design perfect for travel',
      'Timer function prevents all-night operation',
      'Warm light that doesn\'t disrupt sleep',
      'Quick charging via USB'
    ],
    cons: [
      'Limited to only warm white light color',
      'No color-changing options available',
      'Relatively small size may not provide enough light for larger rooms',
      'Touch sensitivity can be inconsistent',
      'Higher price compared to basic night lights'
    ],
    detailedReview: `The VAVA Baby Night Light VA-CL006 stands out as one of the best night lights specifically designed for children and nurseries. Its soft silicone construction makes it completely safe for babies and toddlers to handle, while the warm white LED provides just the right amount of gentle illumination for nighttime navigation without disrupting sleep patterns.

The touch control system is intuitive and child-friendly, allowing even young children to operate the light independently. The 1-hour timer function is particularly useful for bedtime routines, automatically turning off the light after your child falls asleep.

Battery performance is exceptional, with up to 200 hours of operation on the lowest setting. The USB charging system is convenient and the 2.5-hour charging time means minimal downtime. The portable design makes it perfect for travel or moving between rooms.

While the light is limited to warm white only, this is actually beneficial for maintaining healthy sleep cycles. The lack of blue light helps preserve natural melatonin production, making it ideal for bedroom use.`,
    buyingGuide: [
      {
        title: 'Perfect for Ages 0-8',
        description: 'Designed specifically for babies, toddlers, and young children with safety as the top priority.'
      },
      {
        title: 'Bedroom & Nursery Use',
        description: 'Ideal for nurseries, children\'s bedrooms, and as a portable comfort light for travel.'
      },
      {
        title: 'Sleep-Friendly Design',
        description: 'Warm white light won\'t disrupt natural sleep patterns or circadian rhythms.'
      }
    ],
    alternatives: [
      'Philips LED Motion Sensor Night Light',
      'Hatch Rest Sound Machine & Night Light',
      'GE LED+ Night Light Bulb'
    ],
    affiliate: true
  },
  'govee-wifi-led-strip-lights-32-8ft': {
    title: 'Govee WiFi LED Strip Lights 32.8ft',
    description: 'Smart LED strip lights with app control, music sync, and voice control compatibility',
    rating: 4.5,
    price: '$29.99',
    originalPrice: '$39.99',
    image: 'https://images.pexels.com/photos/1406765/pexels-photo-1406765.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'LED Strip Lights',
    categoryPath: '/led-strip-lights',
    features: [
      '32.8ft total length for large installations',
      'WiFi app control with smartphone integration',
      'Music sync responds to sound and rhythm',
      '16 million colors and countless combinations',
      'Voice control compatible with Alexa and Google',
      'DIY mode for custom color creation',
      'Timer and schedule functions',
      'Easy installation with strong adhesive backing'
    ],
    specifications: {
      'Length': '32.8 feet (10 meters)',
      'LED Count': '300 LEDs',
      'Power': '24W',
      'Voltage': '12V DC',
      'Color Range': '16 million colors',
      'Connectivity': 'WiFi 2.4GHz',
      'App': 'Govee Home App',
      'Cutting Points': 'Every 3 LEDs',
      'IP Rating': 'IP20 (indoor use only)'
    },
    pros: [
      'Excellent value for money with 32.8ft length',
      'Responsive and feature-rich mobile app',
      'Music sync works well with various audio sources',
      'Strong adhesive backing stays in place',
      'Wide color range with smooth transitions',
      'Easy setup and installation process',
      'Voice control integration works reliably',
      'Good customer support and warranty'
    ],
    cons: [
      'WiFi setup can be tricky initially',
      'Adhesive may weaken over time in humid conditions',
      'Limited to 2.4GHz WiFi networks only',
      'No waterproof rating for outdoor use',
      'App requires internet connection for full functionality'
    ],
    detailedReview: `The Govee WiFi LED Strip Lights offer exceptional value in the smart lighting category, providing 32.8 feet of vibrant, controllable LED lighting at an affordable price point. The installation process is straightforward, with strong adhesive backing that adheres well to clean surfaces.

The Govee Home app is well-designed and responsive, offering intuitive controls for color selection, brightness adjustment, and scene creation. The music sync feature is particularly impressive, accurately responding to various audio sources and creating dynamic lighting effects that enhance any entertainment setup.

With 16 million color options and smooth transitions, these strips can create virtually any ambiance you desire. The DIY mode allows for custom color creation and pattern design, while preset scenes provide quick access to popular lighting configurations.

Voice control integration with Alexa and Google Assistant works reliably, making it easy to control your lights hands-free. The timer and scheduling functions add convenience for daily routines.

While the initial WiFi setup can be challenging for some users, once connected, the strips perform reliably. The 2.4GHz WiFi requirement may be limiting for some modern networks, but this is common among smart home devices in this price range.`,
    buyingGuide: [
      {
        title: 'Room Size Considerations',
        description: 'Perfect for medium to large rooms, gaming setups, or accent lighting around TV areas and bedrooms.'
      },
      {
        title: 'Smart Home Integration',
        description: 'Works well with existing Alexa or Google Assistant setups for voice control convenience.'
      },
      {
        title: 'Entertainment Enhancement',
        description: 'Music sync feature makes it ideal for parties, gaming, or creating immersive movie experiences.'
      }
    ],
    alternatives: [
      'Philips Hue Lightstrip Plus 6.6ft',
      'LIFX Z LED Strip Light 6.6ft',
      'Nanoleaf Essentials Light Strip 6.6ft'
    ],
    affiliate: true
  },
  'taotronics-led-desk-lamp-tt-dl13': {
    title: 'TaoTronics LED Desk Lamp TT-DL13',
    description: 'Eye-caring LED desk lamp with USB charging port and memory function',
    rating: 4.5,
    price: '$39.99',
    originalPrice: '$49.99',
    image: 'https://images.pexels.com/photos/1002703/pexels-photo-1002703.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'LED Desk Lamps',
    categoryPath: '/led-desk-lamps',
    features: [
      'USB charging port for device convenience',
      '5 color temperature modes (3000K-6000K)',
      '6 brightness levels for optimal lighting',
      'Memory function remembers last settings',
      'Touch-sensitive control panel',
      'Adjustable arm and head positioning',
      'Eye-caring LED technology',
      'Modern minimalist design'
    ],
    specifications: {
      'Power': '14W LED',
      'Color Temperature': '3000K - 6000K',
      'Brightness Levels': '6 levels (10% - 100%)',
      'USB Output': '5V/1A',
      'Adjustability': '180° head rotation, 135° arm rotation',
      'Base Dimensions': '7.1 x 7.1 inches',
      'Height': 'Up to 20 inches',
      'Warranty': '12 months',
      'Certifications': 'FCC, CE'
    },
    pros: [
      'Excellent build quality with premium materials',
      'USB charging port is very convenient for phones and tablets',
      'Wide range of color temperatures suitable for any task',
      'Memory function eliminates need to readjust settings',
      'Smooth and precise adjustment mechanisms',
      'Eye-caring technology reduces strain during long work sessions',
      'Touch controls are responsive and intuitive',
      'Stable base prevents tipping'
    ],
    cons: [
      'Higher price point compared to basic desk lamps',
      'No wireless charging pad built-in',
      'Limited color temperature range compared to premium models',
      'Touch controls can be accidentally activated',
      'Power adapter is somewhat bulky'
    ],
    detailedReview: `The TaoTronics LED Desk Lamp TT-DL13 represents excellent value in the premium desk lamp category, combining functionality, build quality, and eye-care technology in an attractive package. The lamp's construction feels solid and premium, with smooth adjustment mechanisms that maintain their positioning over time.

The 5 color temperature modes range from warm 3000K for relaxed reading to cool 6000K for focused work tasks. Combined with 6 brightness levels, this provides 30 different lighting combinations to suit any activity or time of day. The memory function is particularly useful, automatically returning to your preferred settings when turned on.

The built-in USB charging port is a standout feature, providing convenient device charging without occupying additional desk space. The 5V/1A output is sufficient for smartphones and most tablets, though it won't fast-charge larger devices.

Eye-care technology includes flicker-free operation and blue light optimization, making it comfortable for extended use during work or study sessions. The touch-sensitive controls are responsive and provide tactile feedback, though they can occasionally be triggered accidentally.

The adjustable design allows for precise light positioning, with 180-degree head rotation and 135-degree arm movement providing excellent coverage of your workspace. The weighted base ensures stability even when fully extended.`,
    buyingGuide: [
      {
        title: 'Office & Study Use',
        description: 'Perfect for home offices, study areas, and workspaces requiring adjustable, eye-friendly lighting.'
      },
      {
        title: 'Device Charging Convenience',
        description: 'Built-in USB port makes it ideal for users who need to charge devices while working.'
      },
      {
        title: 'Extended Use Comfort',
        description: 'Eye-care technology makes it suitable for long work sessions and late-night studying.'
      }
    ],
    alternatives: [
      'BenQ ScreenBar Plus Monitor Light',
      'Philips LED Desk Lamp with Wireless Charging',
      'JUKSTG LED Desk Lamp with Eye Protection'
    ],
    affiliate: true
  }
  // Add more products as needed...
};

const ProductDetailPage: React.FC = () => {
  const { productId } = useParams<{ productId: string }>();
  const product = productId ? productDatabase[productId as keyof typeof productDatabase] : null;

  if (!product) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Product Not Found</h1>
          <p className="text-gray-600 mb-6">The product you're looking for doesn't exist.</p>
          <Link to="/" className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors">
            Return to Home
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumb Navigation */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <nav className="flex items-center space-x-2 text-sm">
            <Link to="/" className="text-blue-600 hover:text-blue-800">Home</Link>
            <span className="text-gray-400">/</span>
            <Link to={product.categoryPath} className="text-blue-600 hover:text-blue-800">{product.category}</Link>
            <span className="text-gray-400">/</span>
            <span className="text-gray-600">{product.title}</span>
          </nav>
        </div>
      </div>

      {/* Product Header */}
      <section className="bg-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Product Image */}
            <div className="relative">
              <img
                src={product.image}
                alt={product.title}
                className="w-full h-96 object-cover rounded-lg shadow-lg"
              />
              {product.affiliate && (
                <div className="absolute top-4 right-4 bg-orange-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                  <Award className="h-4 w-4 inline mr-1" />
                  Editor's Choice
                </div>
              )}
            </div>

            {/* Product Info */}
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-4">{product.title}</h1>
              <p className="text-lg text-gray-600 mb-6">{product.description}</p>

              {/* Rating */}
              <div className="flex items-center mb-6">
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-5 w-5 ${
                        i < Math.floor(product.rating)
                          ? 'text-yellow-400 fill-current'
                          : 'text-gray-300'
                      }`}
                    />
                  ))}
                </div>
                <span className="ml-2 text-lg font-medium text-gray-700">
                  {product.rating}/5 (Based on expert review)
                </span>
              </div>

              {/* Price */}
              <div className="mb-6">
                <div className="flex items-center space-x-3">
                  <span className="text-3xl font-bold text-blue-600">{product.price}</span>
                  {product.originalPrice && (
                    <span className="text-xl text-gray-500 line-through">{product.originalPrice}</span>
                  )}
                </div>
                <p className="text-sm text-green-600 mt-1">✓ Best price found online</p>
              </div>

              {/* Key Features */}
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Key Features:</h3>
                <ul className="space-y-2">
                  {product.features.slice(0, 4).map((feature, index) => (
                    <li key={index} className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* CTA Buttons */}
              <div className="space-y-3">
                <button className="w-full bg-blue-600 text-white py-4 px-6 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2 text-lg font-semibold">
                  <ExternalLink className="h-5 w-5" />
                  <span>Check Latest Price & Buy Now</span>
                </button>
                <button className="w-full border-2 border-gray-300 text-gray-700 py-3 px-6 rounded-lg hover:border-gray-400 transition-colors">
                  Compare with Similar Products
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* AdSense Rectangle Ad */}
      <div className="flex justify-center py-8">
        <AdPlacement size="rectangle" position="After Product Header" />
      </div>

      {/* Detailed Review */}
      <section className="py-12 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Expert Review</h2>
          <div className="prose prose-lg max-w-none">
            <p className="text-gray-700 leading-relaxed whitespace-pre-line">
              {product.detailedReview}
            </p>
          </div>
        </div>
      </section>

      {/* Pros and Cons */}
      <section className="py-12 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center">Pros & Cons</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Pros */}
            <div className="bg-green-50 p-6 rounded-lg">
              <h3 className="text-xl font-semibold text-green-900 mb-4 flex items-center">
                <CheckCircle className="h-6 w-6 mr-2" />
                Pros
              </h3>
              <ul className="space-y-3">
                {product.pros.map((pro, index) => (
                  <li key={index} className="flex items-start">
                    <span className="text-green-500 mr-2 mt-1">+</span>
                    <span className="text-green-800">{pro}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Cons */}
            <div className="bg-red-50 p-6 rounded-lg">
              <h3 className="text-xl font-semibold text-red-900 mb-4 flex items-center">
                <XCircle className="h-6 w-6 mr-2" />
                Cons
              </h3>
              <ul className="space-y-3">
                {product.cons.map((con, index) => (
                  <li key={index} className="flex items-start">
                    <span className="text-red-500 mr-2 mt-1">-</span>
                    <span className="text-red-800">{con}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* AdSense Banner Ad */}
      <div className="flex justify-center py-8">
        <AdPlacement size="banner" position="Mid Product Page" />
      </div>

      {/* Specifications */}
      <section className="py-12 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Technical Specifications</h2>
          <div className="bg-gray-50 rounded-lg overflow-hidden">
            <table className="w-full">
              <tbody>
                {Object.entries(product.specifications).map(([key, value], index) => (
                  <tr key={key} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                    <td className="px-6 py-4 font-medium text-gray-900 w-1/3">{key}</td>
                    <td className="px-6 py-4 text-gray-700">{value}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Buying Guide */}
      <section className="py-12 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Who Should Buy This?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {product.buyingGuide.map((guide, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">{guide.title}</h3>
                <p className="text-gray-600">{guide.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Alternative Products */}
      <section className="py-12 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Alternative Products to Consider</h2>
          <div className="bg-blue-50 p-6 rounded-lg">
            <ul className="space-y-3">
              {product.alternatives.map((alternative, index) => (
                <li key={index} className="flex items-center">
                  <Zap className="h-5 w-5 text-blue-600 mr-3" />
                  <span className="text-blue-900 font-medium">{alternative}</span>
                </li>
              ))}
            </ul>
            <div className="mt-4">
              <Link
                to={product.categoryPath}
                className="text-blue-600 hover:text-blue-800 font-medium"
              >
                View all {product.category} reviews →
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-12 bg-blue-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl font-bold text-white mb-4">Ready to Purchase?</h2>
          <p className="text-blue-100 mb-6">
            Get the best deal on the {product.title} from our trusted retail partners.
          </p>
          <button className="bg-white text-blue-600 py-3 px-8 rounded-lg hover:bg-gray-100 transition-colors font-semibold flex items-center justify-center space-x-2 mx-auto">
            <ExternalLink className="h-5 w-5" />
            <span>Check Latest Price & Reviews</span>
          </button>
        </div>
      </section>

      {/* Back to Category */}
      <div className="bg-gray-100 py-6">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link
            to={product.categoryPath}
            className="flex items-center text-blue-600 hover:text-blue-800 font-medium"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            Back to {product.category}
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ProductDetailPage;