// Product data for all LED categories
export interface Product {
  id: string;
  title: string;
  description: string;
  rating: number;
  price: string;
  originalPrice?: string;
  image: string;
  category: string;
  categoryPath: string;
  features: string[];
  specifications: Record<string, string>;
  pros: string[];
  cons: string[];
  detailedReview: string;
  buyingGuide: Array<{
    title: string;
    description: string;
  }>;
  alternatives: string[];
  affiliate?: boolean;
}

export const stripLightProducts: Product[] = [
  {
    id: 'govee-wifi-led-strip-lights-32-8ft',
    title: 'Govee WiFi LED Strip Lights 32.8ft',
    description: 'Smart LED strip lights with app control, music sync, and voice control compatibility',
    rating: 4.5,
    price: '$29.99',
    originalPrice: '$39.99',
    image: 'https://images.pexels.com/photos/1406765/pexels-photo-1406765.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'LED Strip Lights',
    categoryPath: '/led-strip-lights',
    features: [
      '32.8ft total length for large installations',
      'WiFi app control with smartphone integration',
      'Music sync responds to sound and rhythm',
      '16 million colors and countless combinations',
      'Voice control compatible with Alexa and Google',
      'DIY mode for custom color creation',
      'Timer and schedule functions',
      'Easy installation with strong adhesive backing'
    ],
    specifications: {
      'Length': '32.8 feet (10 meters)',
      'LED Count': '300 LEDs',
      'Power': '24W',
      'Voltage': '12V DC',
      'Color Range': '16 million colors',
      'Connectivity': 'WiFi 2.4GHz',
      'App': 'Govee Home App',
      'Cutting Points': 'Every 3 LEDs',
      'IP Rating': 'IP20 (indoor use only)'
    },
    pros: [
      'Excellent value for money with 32.8ft length',
      'Responsive and feature-rich mobile app',
      'Music sync works well with various audio sources',
      'Strong adhesive backing stays in place',
      'Wide color range with smooth transitions',
      'Easy setup and installation process',
      'Voice control integration works reliably',
      'Good customer support and warranty'
    ],
    cons: [
      'WiFi setup can be tricky initially',
      'Adhesive may weaken over time in humid conditions',
      'Limited to 2.4GHz WiFi networks only',
      'No waterproof rating for outdoor use',
      'App requires internet connection for full functionality'
    ],
    detailedReview: `The Govee WiFi LED Strip Lights offer exceptional value in the smart lighting category, providing 32.8 feet of vibrant, controllable LED lighting at an affordable price point. The installation process is straightforward, with strong adhesive backing that adheres well to clean surfaces.

The Govee Home app is well-designed and responsive, offering intuitive controls for color selection, brightness adjustment, and scene creation. The music sync feature is particularly impressive, accurately responding to various audio sources and creating dynamic lighting effects that enhance any entertainment setup.

With 16 million color options and smooth transitions, these strips can create virtually any ambiance you desire. The DIY mode allows for custom color creation and pattern design, while preset scenes provide quick access to popular lighting configurations.

Voice control integration with Alexa and Google Assistant works reliably, making it easy to control your lights hands-free. The timer and scheduling functions add convenience for daily routines.

While the initial WiFi setup can be challenging for some users, once connected, the strips perform reliably. The 2.4GHz WiFi requirement may be limiting for some modern networks, but this is common among smart home devices in this price range.`,
    buyingGuide: [
      {
        title: 'Room Size Considerations',
        description: 'Perfect for medium to large rooms, gaming setups, or accent lighting around TV areas and bedrooms.'
      },
      {
        title: 'Smart Home Integration',
        description: 'Works well with existing Alexa or Google Assistant setups for voice control convenience.'
      },
      {
        title: 'Entertainment Enhancement',
        description: 'Music sync feature makes it ideal for parties, gaming, or creating immersive movie experiences.'
      }
    ],
    alternatives: [
      'Philips Hue Lightstrip Plus 6.6ft',
      'LIFX Z LED Strip Light 6.6ft',
      'Nanoleaf Essentials Light Strip 6.6ft'
    ],
    affiliate: true
  }
];

export const deskLampProducts: Product[] = [
  {
    id: 'taotronics-led-desk-lamp-tt-dl13',
    title: 'TaoTronics LED Desk Lamp TT-DL13',
    description: 'Eye-caring LED desk lamp with USB charging port and memory function',
    rating: 4.5,
    price: '$39.99',
    originalPrice: '$49.99',
    image: 'https://images.pexels.com/photos/1002703/pexels-photo-1002703.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'LED Desk Lamps',
    categoryPath: '/led-desk-lamps',
    features: [
      'USB charging port for device convenience',
      '5 color temperature modes (3000K-6000K)',
      '6 brightness levels for optimal lighting',
      'Memory function remembers last settings',
      'Touch-sensitive control panel',
      'Adjustable arm and head positioning',
      'Eye-caring LED technology',
      'Modern minimalist design'
    ],
    specifications: {
      'Power': '14W LED',
      'Color Temperature': '3000K - 6000K',
      'Brightness Levels': '6 levels (10% - 100%)',
      'USB Output': '5V/1A',
      'Adjustability': '180° head rotation, 135° arm rotation',
      'Base Dimensions': '7.1 x 7.1 inches',
      'Height': 'Up to 20 inches',
      'Warranty': '12 months',
      'Certifications': 'FCC, CE'
    },
    pros: [
      'Excellent build quality with premium materials',
      'USB charging port is very convenient for phones and tablets',
      'Wide range of color temperatures suitable for any task',
      'Memory function eliminates need to readjust settings',
      'Smooth and precise adjustment mechanisms',
      'Eye-caring technology reduces strain during long work sessions',
      'Touch controls are responsive and intuitive',
      'Stable base prevents tipping'
    ],
    cons: [
      'Higher price point compared to basic desk lamps',
      'No wireless charging pad built-in',
      'Limited color temperature range compared to premium models',
      'Touch controls can be accidentally activated',
      'Power adapter is somewhat bulky'
    ],
    detailedReview: `The TaoTronics LED Desk Lamp TT-DL13 represents excellent value in the premium desk lamp category, combining functionality, build quality, and eye-care technology in an attractive package. The lamp's construction feels solid and premium, with smooth adjustment mechanisms that maintain their positioning over time.

The 5 color temperature modes range from warm 3000K for relaxed reading to cool 6000K for focused work tasks. Combined with 6 brightness levels, this provides 30 different lighting combinations to suit any activity or time of day. The memory function is particularly useful, automatically returning to your preferred settings when turned on.

The built-in USB charging port is a standout feature, providing convenient device charging without occupying additional desk space. The 5V/1A output is sufficient for smartphones and most tablets, though it won't fast-charge larger devices.

Eye-care technology includes flicker-free operation and blue light optimization, making it comfortable for extended use during work or study sessions. The touch-sensitive controls are responsive and provide tactile feedback, though they can occasionally be triggered accidentally.

The adjustable design allows for precise light positioning, with 180-degree head rotation and 135-degree arm movement providing excellent coverage of your workspace. The weighted base ensures stability even when fully extended.`,
    buyingGuide: [
      {
        title: 'Office & Study Use',
        description: 'Perfect for home offices, study areas, and workspaces requiring adjustable, eye-friendly lighting.'
      },
      {
        title: 'Device Charging Convenience',
        description: 'Built-in USB port makes it ideal for users who need to charge devices while working.'
      },
      {
        title: 'Extended Use Comfort',
        description: 'Eye-care technology makes it suitable for long work sessions and late-night studying.'
      }
    ],
    alternatives: [
      'BenQ ScreenBar Plus Monitor Light',
      'Philips LED Desk Lamp with Wireless Charging',
      'JUKSTG LED Desk Lamp with Eye Protection'
    ],
    affiliate: true
  }
];

export const nightLightProducts: Product[] = [
  {
    id: 'vava-baby-night-light-va-cl006',
    title: 'VAVA Baby Night Light VA-CL006',
    description: 'Soft silicone night light with touch control and timer function',
    rating: 4.6,
    price: '$19.99',
    originalPrice: '$24.99',
    image: 'https://images.pexels.com/photos/1329297/pexels-photo-1329297.jpeg?auto=compress&cs=tinysrgb&w=600',
    category: 'LED Night Lights',
    categoryPath: '/led-night-lights',
    features: [
      'Soft silicone design safe for children',
      'Touch control with easy operation',
      '1-hour auto timer function',
      'USB rechargeable battery',
      'Warm white LED light',
      'Portable and lightweight design',
      'BPA-free materials',
      'Multiple brightness levels'
    ],
    specifications: {
      'Dimensions': '4.3 x 4.3 x 4.7 inches',
      'Weight': '8.8 ounces',
      'Battery Life': 'Up to 200 hours (lowest setting)',
      'Charging Time': '2.5 hours',
      'Light Color': 'Warm White (3000K)',
      'Material': 'Food-grade silicone',
      'Warranty': '18 months',
      'Certifications': 'FCC, CE, RoHS'
    },
    pros: [
      'Completely safe for children with soft silicone construction',
      'Excellent battery life lasting up to 200 hours',
      'Cute and appealing design that kids love',
      'Easy touch controls that children can operate',
      'Portable design perfect for travel',
      'Timer function prevents all-night operation',
      'Warm light that doesn\'t disrupt sleep',
      'Quick charging via USB'
    ],
    cons: [
      'Limited to only warm white light color',
      'No color-changing options available',
      'Relatively small size may not provide enough light for larger rooms',
      'Touch sensitivity can be inconsistent',
      'Higher price compared to basic night lights'
    ],
    detailedReview: `The VAVA Baby Night Light VA-CL006 stands out as one of the best night lights specifically designed for children and nurseries. Its soft silicone construction makes it completely safe for babies and toddlers to handle, while the warm white LED provides just the right amount of gentle illumination for nighttime navigation without disrupting sleep patterns.

The touch control system is intuitive and child-friendly, allowing even young children to operate the light independently. The 1-hour timer function is particularly useful for bedtime routines, automatically turning off the light after your child falls asleep.

Battery performance is exceptional, with up to 200 hours of operation on the lowest setting. The USB charging system is convenient and the 2.5-hour charging time means minimal downtime. The portable design makes it perfect for travel or moving between rooms.

While the light is limited to warm white only, this is actually beneficial for maintaining healthy sleep cycles. The lack of blue light helps preserve natural melatonin production, making it ideal for bedroom use.`,
    buyingGuide: [
      {
        title: 'Perfect for Ages 0-8',
        description: 'Designed specifically for babies, toddlers, and young children with safety as the top priority.'
      },
      {
        title: 'Bedroom & Nursery Use',
        description: 'Ideal for nurseries, children\'s bedrooms, and as a portable comfort light for travel.'
      },
      {
        title: 'Sleep-Friendly Design',
        description: 'Warm white light won\'t disrupt natural sleep patterns or circadian rhythms.'
      }
    ],
    alternatives: [
      'Philips LED Motion Sensor Night Light',
      'Hatch Rest Sound Machine & Night Light',
      'GE LED+ Night Light Bulb'
    ],
    affiliate: true
  }
];

// Export all products combined for easy access
export const allProducts = {
  ...stripLightProducts.reduce((acc, product) => ({ ...acc, [product.id]: product }), {}),
  ...deskLampProducts.reduce((acc, product) => ({ ...acc, [product.id]: product }), {}),
  ...nightLightProducts.reduce((acc, product) => ({ ...acc, [product.id]: product }), {}),
};